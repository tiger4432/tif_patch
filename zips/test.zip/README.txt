# Wafer Patch Extraction Data

TIFF File: realistic_wafer_sample_fast
Extraction Date: 2025-09-28T15:02:59.352Z
Version: v2

## Grid Settings
- Columns: 6
- Rows: 6
- Cell Width: 170px
- Cell Height: 170px

## Alignment
- Origin: (161, -6)
- Reference Grid: (0, 0)

## Enhancement Settings
- Alpha (Contrast): undefined
- Beta (Brightness): undefined
- Target Mean: 0.5
- Target Std: 0.2
- Padding: 30px

## Extraction Info
- Total Pages: 8
- Total Coordinates: 6
- Total Patches: 48
- Patch Size: 300px

## Folder Structure
- no_voids/[type]/layer_[XX]/[patch_name].png (patches without voids)
- split/[type]/layer_[XX]/[patch_name].png (patches with void markings)
- merge/[type]/[patch_name]_merge.png (merged mask layers)
- summary/[type]_summary.png (type-based void pattern summaries)
- metadata.json: Grid and extraction settings
- coordinates.json: Chip coordinate data
- voids.json: Void detection data
- bin_map.txt: Bin classification map with X,Y axis labels (tab-separated)
- bonding_map.txt: Chip presence map with X,Y axis labels (tab-separated, 1=chip, 0=empty)
- bin_statistics.json: Bin distribution statistics

## Bin Classification Rules
- BIN10 (Red): void39, signal defects - highest priority
- BIN6 (Purple): particle defects
- BIN4 (Orange): void defects
- BIN3 (Green): edge defects
- BIN2 (Blue): dela defects
- BIN1 (Skyblue): no defects - default
